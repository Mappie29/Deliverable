package testng;

import jdk.jfr.Threshold;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.List;

public class testng1
{
    WebDriver wd;
    @BeforeMethod
    public void setup()
    {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\manoj.paliwal\\IdeaProjects\\seleb\\chromedriver.exe");
        wd=new ChromeDriver();
        wd.get("https://www.zostel.com/");
        wd.manage().window().maximize();
    }
    @AfterMethod
    public void close()
    {
        wd.close();
    }

    @Test(priority = 1)
    public void locationClick() throws InterruptedException {
        JavascriptExecutor nm=((JavascriptExecutor)wd);
        nm.executeScript("window.scrollBy(0,300)");
        Thread.sleep(2000);
        wd.findElement(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[1]/div/div")).click();
        Thread.sleep(2000);
        List<WebElement> wer=wd.findElements(By.xpath("//div[@class=\"select\"]//ul//li"));
        for(WebElement x:wer)
        {
            String s=x.getText();
            if(s.equalsIgnoreCase("Bangalore"))
            {
                x.click();
            }
        }

        wd.findElement(By.xpath("//*[@id=\"check-in-lg\"]")).click();
        List<WebElement>tr=wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button"));
        //System.out.println(tr.size());
        for(int i=1;i<=tr.size();i++)
        {
            String s=wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).getText();
            if(s.equalsIgnoreCase("28"))
            {
                wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).click();
                break;
            }
        }
        Thread.sleep(2000);

        wd.findElement(By.xpath("//input[@id=\"check-out-lg\"]")).click();
        List<WebElement>tp=wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button"));
        System.out.println(tp.size());
        for(int i=1;i<=tp.size();i++)
        {
            String s=wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).getText();
            if(s.equalsIgnoreCase("30"))
            {
                wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).click();
                break;
            }
        }
        Thread.sleep(2000);

        wd.findElement(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[4]/button")).click();;
        Thread.sleep(4000);
    }
}
