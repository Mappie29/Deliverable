import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
public class Hostel {
    static Boolean validate_date(WebDriver wd,String date){
        List<WebElement>dis=wd.findElements(By.xpath("//div[@class=\"pika-lendar\"]//table//tbody//tr//td[@class=\"is-disabled\"]"));
        for(WebElement i: dis) {
            if (i.getText().equals(date)) ;
            {
                return false;
            }
        }
        return true;
    }
    static void setdate(WebDriver wd,String date,String date2) {

        if (validate_date(wd, "23"))
        {

        }
    }
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\manoj.paliwal\\IdeaProjects\\seleb\\chromedriver.exe");
        WebDriver wd=new ChromeDriver();
        wd.get("https://www.zostel.com/");
        wd.manage().window().maximize();
        //scroll down
        JavascriptExecutor nm=((JavascriptExecutor)wd);
        nm.executeScript("window.scrollBy(0,300)");
        wd.findElement(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[1]/div/div")).click();
        Thread.sleep(2000);
        //List<WebElement> wer=wd.findElements(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[1]/div/ul"));
        List<WebElement> wer=wd.findElements(By.xpath("//div[@class=\"select\"]//ul//li"));
        /*int z=wer.size();
        for(int i=1;i<=z;i++)
        {
            String text=wd.findElement(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[1]/div/ul/li["+i+"]")).getText();
            System.out.println(text);
            if(text.equalsIgnoreCase("Bangalore")) {
                System.out.println("Hi");
              wd.findElement(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[1]/div/ul/li["+i+"]")).click();
            }
        }*/
        for(WebElement x:wer)
        {
            String s=x.getText();
            if(s.equalsIgnoreCase("Bangalore"))
            {
                x.click();
                Thread.sleep(3000);
            }//input[@id='check-in-lg']
        }
        wd.findElement(By.xpath("//*[@id=\"check-in-lg\"]")).click();
        List<WebElement>tr=wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button"));
        //System.out.println(tr.size());
        for(int i=1;i<=tr.size();i++)
        {
            String s=wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).getText();
            if(s.equalsIgnoreCase("28"))
            {
                wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).click();
                break;
            }
        }
        Thread.sleep(2000);
        wd.findElement(By.xpath("//input[@id=\"check-out-lg\"]")).click();
        List<WebElement>tp=wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button"));
        System.out.println(tr.size());
        for(int i=1;i<=tp.size();i++)
        {
            String s=wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).getText();
            if(s.equalsIgnoreCase("30"))
            {
                wd.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).click();
                break;
            }
        }

//        setdate(wd,"20","25");
//        Date d = new Date(1);
//        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
//        String date = formatter.format(d);
//        String splitter[] = date.split("-");
//        String month_year = splitter[1];
//        String day = splitter[0];
//        System.out.println(month_year);
//        System.out.println(day);
        wd.findElement(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[4]/button")).click();;
        Thread.sleep(4000);
        List<WebElement>tu=wd.findElements(By.xpath("//div[contains(@class,'flex flex-col')]//div[@class='flex flex-col']//span[contains(@class,'sm:text-xl')]"));
        Thread.sleep(4000);
        int r=tu.size();
        System.out.println(r);
//        for(int j=0;j<r;j++)
//        {
//            System.out.println(wd.findElements(By.xpath("//span[@class=\"sm:text-xl font-semibold leading-snug block\"]")).get(j).getText());
//        }
        for(WebElement c:tu)
        {
            System.out.println(c.getText());
        }
    }
}





