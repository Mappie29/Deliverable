package stepdef;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import setuuu.Excelutil;
import setuuu.setup;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class stepdefinations {
    WebDriver driver;
    setup a=new setup();
    Excelutil ee=new Excelutil();
    @Before
    public void setup_b() throws IOException {
        try{
            driver = a.initializeDriver();
        }
        catch (Exception e)
            {
                System.err.println(e.getMessage());
            }

    }

    @Given("Open the Zostel url")
    public void open_the_zostel_url() throws InterruptedException {
        try{
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            driver.get("https://www.zostel.com/");
            Thread.sleep(2000);
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
    }

    @When("I enter for the location with Check in and check out date")
    public void i_enter_for_the_location_with_check_in_and_check_out_date()throws InterruptedException, IOException {
        try{
            String loc = ee.read_excel();
            JavascriptExecutor nm = ((JavascriptExecutor) driver);
            nm.executeScript("window.scrollBy(0,500)");
            Thread.sleep(3000);
            driver.findElement(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[1]/div/div")).click();
            Thread.sleep(4000);
            //driver.findElement(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[1]/div/ul/li[3]")).click();
            List<WebElement> wer = driver.findElements(By.xpath("//div[@class=\"select\"]//ul//li"));
            int count = 0;
            for (int i = 1; i < wer.size(); i++) {
                String s = driver.findElements(By.xpath("//div[@class=\"select\"]//ul//li")).get(i).getText();
                System.out.println(s);
                if (i % 10 == 0) {
                    count++;
                    nm.executeScript("window.scrollBy(0,200)");
                    Thread.sleep(3000);
                }
                if (s.equalsIgnoreCase(loc)) {
                    driver.findElement(By.xpath("//li[text()=\"" + loc + "\"]")).click();

//                WebDriverWait wait=new WebDriverWait(driver,10);
//                wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//div[@class=\"select\"]//ul//li"))));
//                Thread.sleep(5000);
//                System.out.println("Hi");
//                driver.findElement(By.xpath("//div[@class=\"select\"]//ul//li")).click();
//                Thread.sleep(3000);
//                WebElement w = driver.findElement(By.xpath("//div[@class=\"select\"]//ul//li"));
//                Actions act=new Actions(driver);
//                act.moveToElement(loc).click(wer).perform();
//                driver.findElement(By.xpath("//div[@class=\"select\"]//ul//li"+"["+i+"]")).click();
                    //nm.executeScript("document.getElementsByXpath('//div[@class=\"select\"]//ul//li["+i+"]').click()");
                }
            }
            for (int i = 0; i < count; i++) {
                nm.executeScript("window.scrollBy(0,-200)");
            }
            driver.findElement(By.xpath("//*[@id=\"check-in-lg\"]")).click();
            List<WebElement> tr = driver.findElements(By.xpath("//td[@aria-selected=\"false\"]/button"));
            //System.out.println(tr.size());
            for (int i = 1; i <= tr.size(); i++) {
                String s = driver.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).getText();
                if (s.equalsIgnoreCase("28")) {
                    driver.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).click();
                    break;
                }
            }
            Thread.sleep(2000);

            driver.findElement(By.xpath("//input[@id=\"check-out-lg\"]")).click();
            List<WebElement> tp = driver.findElements(By.xpath("//td[@aria-selected=\"false\"]/button"));
            System.out.println(tp.size());
            for (int i = 1; i <= tp.size(); i++) {
                String s = driver.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).getText();
                if (s.equalsIgnoreCase("29")) {
                    driver.findElements(By.xpath("//td[@aria-selected=\"false\"]/button")).get(i).click();
                    break;
                }
            }
            Thread.sleep(2000);
            driver.findElement(By.xpath("/html/body/div[2]/div[6]/div[3]/form/div[4]/button")).click();
            Thread.sleep(4000);
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
    }

    @Then("I should get Suggestion for Hotels")
    public void i_should_get_suggestion_for_hotels() throws InterruptedException {

        try{
            List<WebElement> tu = driver.findElements(By.xpath("//div[contains(@class,'flex flex-col')]//div[@class='flex flex-col']//span[contains(@class,'sm:text-xl')]"));
            Thread.sleep(4000);
            int r = tu.size();
            System.out.println(r);
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
//        for(int j=0;j<r;j++)
//        {
//            System.out.println(wd.findElements(By.xpath("//span[@class=\"sm:text-xl font-semibold leading-snug block\"]")).get(j).getText());
//        }
//        for(WebElement c:tu)
//        {
//            System.out.println(c.getText());
//        }
    }
}
//excel data read (location) or data driven
//serenity with cucumber
//project files---->driver path etc.(serenity.properties files)
//report generate
//multiple browser test
//
